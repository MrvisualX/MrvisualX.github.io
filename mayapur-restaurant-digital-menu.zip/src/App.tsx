import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Utensils, 
  Coffee, 
  GlassWater, 
  Star, 
  ChevronRight, 
  Phone, 
  MapPin, 
  Clock,
  Menu as MenuIcon,
  X
} from "lucide-react";

// --- Types ---
interface MenuItem {
  id: string;
  name: string;
  description?: string;
  price: number;
  category: "special" | "food" | "drink";
  image?: string;
}

// --- Data ---
const MENU_ITEMS: MenuItem[] = [
  {
    id: "s1",
    name: "Basanti Pulao + Mutton Kosha Combo",
    description: "Served with Salad + Papad + Rasgulla + 2 Mocktails. A complete royal feast.",
    price: 800,
    category: "special",
    image: "https://picsum.photos/seed/mutton/600/400"
  },
  {
    id: "s2",
    name: "Basanti Pulao + Chicken Kosha Combo",
    description: "Served with Salad + Papad + Rasgulla + 2 Mocktails. Perfect for a hearty meal.",
    price: 700,
    category: "special",
    image: "https://picsum.photos/seed/chicken/600/400"
  },
  {
    id: "f1",
    name: "Mutton Kosha",
    description: "Slow-cooked tender mutton in a rich, spicy gravy.",
    price: 450,
    category: "food"
  },
  {
    id: "f2",
    name: "Chicken Kosha",
    description: "Classic Bengali style chicken curry with aromatic spices.",
    price: 350,
    category: "food"
  },
  {
    id: "f3",
    name: "Basanti Pulao",
    description: "Fragrant yellow rice cooked with ghee, saffron, and dry fruits.",
    price: 200,
    category: "food"
  },
  {
    id: "d1",
    name: "Mango Mocktail",
    description: "Refreshing blend of ripe mangoes and mint.",
    price: 120,
    category: "drink"
  },
  {
    id: "d2",
    name: "Strawberry Mocktail",
    description: "Sweet and tangy strawberry delight with a fizz.",
    price: 140,
    category: "drink"
  },
  {
    id: "d3",
    name: "Cold Coffee",
    description: "Creamy, chilled coffee topped with chocolate syrup.",
    price: 150,
    category: "drink"
  }
];

// --- Components ---

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "Specials", href: "#specials" },
    { name: "Food", href: "#food" },
    { name: "Drinks", href: "#drinks" },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "bg-white/90 backdrop-blur-md shadow-sm py-3" : "bg-transparent py-6"}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="bg-amber-600 p-2 rounded-lg">
            <Utensils className="text-white w-5 h-5" />
          </div>
          <span className={`font-serif text-xl font-bold tracking-tight ${scrolled ? "text-stone-900" : "text-white"}`}>
            Mayapur Restaurant
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              className={`text-sm font-medium transition-colors ${scrolled ? "text-stone-600 hover:text-amber-600" : "text-white/80 hover:text-white"}`}
            >
              {link.name}
            </a>
          ))}
          <button className="bg-amber-600 hover:bg-amber-700 text-white px-5 py-2 rounded-full text-sm font-semibold transition-all shadow-lg shadow-amber-600/20">
            Order Now
          </button>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-stone-900" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X className={scrolled ? "text-stone-900" : "text-white"} /> : <MenuIcon className={scrolled ? "text-stone-900" : "text-white"} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-white shadow-xl border-t border-stone-100 p-6 md:hidden"
          >
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="text-stone-600 font-medium hover:text-amber-600 py-2 border-b border-stone-50"
                >
                  {link.name}
                </a>
              ))}
              <button className="bg-amber-600 text-white w-full py-3 rounded-xl font-semibold mt-2">
                Order Now
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const MenuCard = ({ item, onOrder }: { item: MenuItem; onOrder: (name: string) => void; key?: string }) => {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm hover:shadow-md transition-all group"
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-serif text-lg font-bold text-stone-900 group-hover:text-amber-700 transition-colors">
          {item.name}
        </h3>
        <span className="text-amber-600 font-bold">₹{item.price}</span>
      </div>
      {item.description && (
        <p className="text-stone-500 text-sm leading-relaxed mb-4">
          {item.description}
        </p>
      )}
      <button 
        onClick={() => onOrder(item.name)}
        className="flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-stone-400 group-hover:text-amber-600 transition-colors"
      >
        Add to Order <ChevronRight className="w-3 h-3" />
      </button>
    </motion.div>
  );
};

const SpecialCard = ({ item, onOrder }: { item: MenuItem; onOrder: (name: string) => void; key?: string }) => {
  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      className="relative overflow-hidden rounded-3xl bg-stone-900 text-white shadow-2xl group"
    >
      <div className="absolute inset-0 opacity-40 group-hover:opacity-50 transition-opacity">
        <img 
          src={item.image} 
          alt={item.name} 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-stone-900 via-stone-900/60 to-transparent" />
      
      <div className="relative p-8 h-full flex flex-col justify-end min-h-[400px]">
        <div className="flex items-center gap-2 mb-3">
          <div className="bg-amber-500 text-stone-900 text-[10px] font-black uppercase px-2 py-1 rounded">
            Today's Special
          </div>
          <div className="flex gap-0.5">
            {[1,2,3,4,5].map(i => <Star key={i} className="w-3 h-3 fill-amber-500 text-amber-500" />)}
          </div>
        </div>
        <h3 className="font-serif text-3xl font-bold mb-3 leading-tight">
          {item.name}
        </h3>
        <p className="text-stone-300 text-sm mb-6 max-w-md">
          {item.description}
        </p>
        <div className="flex items-center justify-between">
          <span className="text-3xl font-bold text-amber-500">₹{item.price}</span>
          <button 
            onClick={() => onOrder(item.name)}
            className="bg-white text-stone-900 px-6 py-3 rounded-full font-bold hover:bg-amber-500 transition-colors"
          >
            Order Combo
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default function App() {
  const [showToast, setShowToast] = useState<string | null>(null);

  const handleOrder = (itemName: string) => {
    setShowToast(itemName);
    setTimeout(() => setShowToast(null), 3000);
  };

  return (
    <div className="min-h-screen bg-[#FDFCF9] text-stone-900 selection:bg-amber-100 selection:text-amber-900">
      <Navbar />

      {/* Toast Notification */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 50, x: "-50%" }}
            className="fixed bottom-10 left-1/2 z-[100] bg-stone-900 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 border border-white/10"
          >
            <div className="bg-amber-500 rounded-full p-1">
              <Star className="w-3 h-3 text-stone-900 fill-stone-900" />
            </div>
            <span className="text-sm font-medium">Added <span className="text-amber-400 font-bold">{showToast}</span> to your order!</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/seed/restaurant/1920/1080" 
            className="w-full h-full object-cover"
            alt="Restaurant Interior"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-[2px]" />
        </div>

        <div className="relative z-10 text-center px-6 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block text-amber-500 font-bold tracking-[0.2em] uppercase text-sm mb-6">
              Authentic Flavors of Mayapur
            </span>
            <h1 className="font-serif text-6xl md:text-8xl text-white font-bold mb-8 leading-tight">
              A Taste of <span className="italic text-amber-500">Tradition</span>
            </h1>
            <p className="text-stone-200 text-lg md:text-xl mb-10 max-w-2xl mx-auto leading-relaxed font-light">
              Experience the finest Bengali cuisine crafted with love and heritage. 
              From slow-cooked mutton to fragrant pulao, every bite tells a story.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a href="#specials" className="bg-amber-600 hover:bg-amber-700 text-white px-10 py-4 rounded-full font-bold text-lg transition-all shadow-xl shadow-amber-600/20 w-full sm:w-auto">
                Explore Menu
              </a>
              <a href="#food" className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/30 px-10 py-4 rounded-full font-bold text-lg transition-all w-full sm:w-auto">
                Full Menu
              </a>
            </div>
          </motion.div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center p-1">
            <div className="w-1 h-2 bg-white rounded-full" />
          </div>
        </div>
      </section>

      {/* Specials Section */}
      <section id="specials" className="py-24 px-6 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4">Today's Specials</h2>
            <p className="text-stone-500 max-w-md">Our chef's curated combinations for the ultimate dining experience.</p>
          </div>
          <div className="flex items-center gap-2 text-amber-600 font-bold">
            <span>View All Offers</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {MENU_ITEMS.filter(i => i.category === "special").map(item => (
            <SpecialCard key={item.id} item={item} onOrder={handleOrder} />
          ))}
        </div>
      </section>

      {/* Food Section */}
      <section id="food" className="py-24 bg-stone-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-amber-100 text-amber-800 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-4">
              <Utensils className="w-3 h-3" /> Main Course
            </div>
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4">Food Menu</h2>
            <p className="text-stone-500 max-w-lg mx-auto">Traditional Bengali delicacies prepared with authentic spices and techniques.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {MENU_ITEMS.filter(i => i.category === "food").map(item => (
              <MenuCard key={item.id} item={item} onOrder={handleOrder} />
            ))}
          </div>
        </div>
      </section>

      {/* Drinks Section */}
      <section id="drinks" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-800 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-4">
              <GlassWater className="w-3 h-3" /> Refreshments
            </div>
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4">Drinks & Mocktails</h2>
            <p className="text-stone-500 max-w-lg mx-auto">Cool down with our refreshing selection of handcrafted beverages.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {MENU_ITEMS.filter(i => i.category === "drink").map(item => (
              <MenuCard key={item.id} item={item} onOrder={handleOrder} />
            ))}
          </div>
        </div>
      </section>

      {/* Footer / Contact */}
      <footer className="bg-stone-900 text-white py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-16">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <div className="bg-amber-600 p-2 rounded-lg">
                  <Utensils className="text-white w-5 h-5" />
                </div>
                <span className="font-serif text-2xl font-bold tracking-tight">
                  Mayapur Restaurant
                </span>
              </div>
              <p className="text-stone-400 leading-relaxed mb-8">
                Bringing the authentic taste of Bengal to your table. We pride ourselves on quality, heritage, and hospitality.
              </p>
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-stone-800 flex items-center justify-center hover:bg-amber-600 transition-colors cursor-pointer">
                  <Phone className="w-4 h-4" />
                </div>
                <div className="w-10 h-10 rounded-full bg-stone-800 flex items-center justify-center hover:bg-amber-600 transition-colors cursor-pointer">
                  <MapPin className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-6">Quick Links</h4>
              <ul className="space-y-4 text-stone-400">
                <li><a href="#home" className="hover:text-amber-500 transition-colors">Home</a></li>
                <li><a href="#specials" className="hover:text-amber-500 transition-colors">Today's Specials</a></li>
                <li><a href="#food" className="hover:text-amber-500 transition-colors">Food Menu</a></li>
                <li><a href="#drinks" className="hover:text-amber-500 transition-colors">Drinks Menu</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-6">Visit Us</h4>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <MapPin className="text-amber-500 w-5 h-5 shrink-0" />
                  <p className="text-stone-400">123 Temple Road, Mayapur,<br />West Bengal, India</p>
                </div>
                <div className="flex gap-4">
                  <Clock className="text-amber-500 w-5 h-5 shrink-0" />
                  <p className="text-stone-400">Open Daily: 11:00 AM - 11:00 PM</p>
                </div>
                <div className="flex gap-4">
                  <Phone className="text-amber-500 w-5 h-5 shrink-0" />
                  <p className="text-stone-400">+91 98765 43210</p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-12 border-t border-stone-800 flex flex-col md:flex-row justify-between items-center gap-6 text-stone-500 text-sm">
            <p>© 2024 Mayapur Restaurant. All rights reserved.</p>
            <div className="flex gap-8">
              <span className="hover:text-stone-300 cursor-pointer">Privacy Policy</span>
              <span className="hover:text-stone-300 cursor-pointer">Terms of Service</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
